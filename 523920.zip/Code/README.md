# swarm intelligence project

small ARGoS swarm robotics project for a tunnelling task

This repo can be found at [https://github.com/ldevroye/swarm_intelligence](https://github.com/ldevroye/swarm_intelligence)

## goal

maximize the score

score = #robots in black zone - #obstacles in black zone

this is a local reactive controller for foot-bot robots running in ARGoS

## project layout

- `controller.lua` : main robot controller
- `baseline.lua` : naive, comparison controller
- `blind.argos` : main experiment (headless) config used by the project
- `script.argos` : visual run
- `build.sh` : build helper for the ARGoS plugin
- `src/` : native C++ plugin sources
- `doc/` : project notes and technical references
- `exercices/` : course examples and reference controllers

## run

1. build the plugin

```bash
./build.sh
```

2. run the experiment headless

```bash
srcargos && argos3 -c blind.argos
```

or, if the project is configured to use the provided wrapper:

```bash
srcargos && argos3 -c blind.argos 2>out.txt
```
to run the headless script.

Or, if you want to see LEDs and bots :
```bash
srcargos && argos3 -c script.argos 2>out.txt
```


## important notes

- the controller is loaded by `.argos` scripts via the `script` param
- the simulation uses a black target area and a light source
- robot behavior is based on local sensing and local communication
- logs are written per robot under the `logs/` folder

## data to inspect

- `output.txt` : simulation output from loop functions
- `logs/` : per-robot log files

## behavior overview

- orient toward light and establish swarm spacing
- form a group in the tunnel phase
- move toward the black target zone
- maintain low-level obstacle avoidance and black-floor tracking

## LICENCE
MIT